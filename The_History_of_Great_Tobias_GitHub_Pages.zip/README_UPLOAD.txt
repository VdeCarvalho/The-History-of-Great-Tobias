THE HISTORY OF GREAT TOBIAS — GITHUB PAGES

Envie todos estes arquivos para a RAIZ do repositório:
index.html
jogo.html
styles.css
script.js
tobias_intro.mp4
tobias_theme.mp3

Dimensões fixas:
Publicidade: 1170 x 350 px
Jogo: 1170 x 1890 px

A música é uma composição original para o protótipo. Não contém samples
nem melodias de Albion Online; a referência foi apenas o caráter geral
medieval/orquestral heroico.

Observação: Chrome/Safari podem bloquear áudio automático até o primeiro
toque/clique. A página tenta iniciar a trilha e, se bloqueada, começa no
primeiro gesto do usuário. O botão ♪ permite ligar/desligar.
